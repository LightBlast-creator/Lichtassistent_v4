from typing import List, Dict, Optional
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    abort,
    send_file,
)
import json
import os
import io
import copy

from reportlab.lib.pagesizes import A4  # type: ignore
from reportlab.lib.utils import ImageReader  # type: ignore
from reportlab.pdfgen import canvas  # type: ignore

# -----------------------------------------------------------------------------
# Flask-App
# -----------------------------------------------------------------------------

app = Flask(__name__, template_folder="App")

DATA_FILE = "shows.json"

Show = Dict
Song = Dict

shows: List[Show] = []
next_show_id: int = 1
next_song_id: int = 1
next_check_item_id: int = 1

# -----------------------------------------------------------------------------
# Helper-Funktionen / Defaults
# -----------------------------------------------------------------------------

def _empty_rig_setup() -> Dict:
    return {
        "spots": "",
        "washes": "",
        "beams": "",
        "blinders": "",
        "strobes": "",
        "positions": "",
        "notes": "",
        # optionale Felder aus älteren Ständen:
        "count_spots": "",
        "count_washes": "",
        "count_beams": "",
        "count_blinders": "",
        "count_strobes": "",
        "truss_info": "",
        "truss_height": "",
        "specials": "",
        # neue Felder für Strom / Infrastruktur
        "power_main": "",
        "power_light": "",
        "power_sound": "",
        "power_video": "",
        "power_foh": "",
        "power_other": "",
    }


def _empty_checklists() -> Dict:
    return {
        "preproduction": [],
        "aufbau": [],
        "show": [],
    }


def load_data() -> None:
    """Lädt Shows + IDs aus shows.json, falls vorhanden, und sorgt für Defaults."""
    global shows, next_show_id, next_song_id, next_check_item_id

    if not os.path.exists(DATA_FILE):
        return

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return

    shows_data = data.get("shows", [])
    next_show_id = data.get("next_show_id", 1)
    next_song_id = data.get("next_song_id", 1)
    next_check_item_id = data.get("next_check_item_id", 1)

    normalized_shows: List[Show] = []
    for raw_show in shows_data:
        show = dict(raw_show)

        # Basisfelder
        show.setdefault("id", len(normalized_shows) + 1)
        show.setdefault("name", f"Show {show.get('id', 0)}")
        show.setdefault("artist", "")
        show.setdefault("date", "")
        show.setdefault("venue_type", "")
        show.setdefault("genre", "")
        show.setdefault("rig_type", "")

        # Stammdaten-Extras
        for key in ("regie", "veranstalter", "vt_firma", "technischer_leiter", "notes"):
            show.setdefault(key, "")

        # Songs-Liste
        songs = show.get("songs")
        if not isinstance(songs, list):
            songs = []
        for idx, s in enumerate(songs, start=1):
            s.setdefault("id", idx)
            s.setdefault("order_index", idx)
            s.setdefault("name", f"Song {idx}")
            s.setdefault("mood", "")
            s.setdefault("colors", "")
            s.setdefault("movement_style", "")
            s.setdefault("eye_candy", "")
            s.setdefault("special_notes", "")
            s.setdefault("general_notes", "")
        show["songs"] = songs

        # Rig-Struktur
        rig = show.get("rig_setup")
        if not isinstance(rig, dict):
            rig = _empty_rig_setup()
        else:
            defaults = _empty_rig_setup()
            for key, default_val in defaults.items():
                rig.setdefault(key, default_val)
        show["rig_setup"] = rig

        # Checklisten-Struktur
        cl = show.get("checklists")
        if not isinstance(cl, dict):
            cl = _empty_checklists()
        else:
            for key in ("preproduction", "aufbau", "show"):
                items = cl.get(key)
                if not isinstance(items, list):
                    items = []
                cl[key] = items
        show["checklists"] = cl

        normalized_shows.append(show)

    shows.clear()
    shows.extend(normalized_shows)


def save_data() -> None:
    """Speichert Shows + IDs nach shows.json."""
    data = {
        "shows": shows,
        "next_show_id": next_show_id,
        "next_song_id": next_song_id,
        "next_check_item_id": next_check_item_id,
    }
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def find_show(show_id: int) -> Optional[Show]:
    for show in shows:
        if show.get("id") == show_id:
            return show
    return None


def create_default_show(
    name: str,
    artist: str,
    date: str,
    venue_type: str,
    genre: str,
    rig_type: str,
) -> Show:
    global next_show_id

    show: Show = {
        "id": next_show_id,
        "name": name or f"Show {next_show_id}",
        "artist": artist or "",
        "date": date or "",
        "venue_type": venue_type or "",
        "genre": genre or "",
        "rig_type": rig_type or "",
        "regie": "",
        "veranstalter": "",
        "vt_firma": "",
        "technischer_leiter": "",
        "notes": "",
        "songs": [],
        "rig_setup": _empty_rig_setup(),
        "checklists": _empty_checklists(),
    }

    next_show_id += 1
    return show


def create_song(
    show: Show,
    name: str,
    mood: str,
    colors: str,
    movement_style: str,
    eye_candy: str,
    special_notes: str,
    general_notes: str,
) -> Song:
    """Fügt der Show einen neuen Song/Szene hinzu."""
    global next_song_id

    order_index = len(show["songs"]) + 1

    song: Song = {
        "id": next_song_id,
        "name": name or f"Song {order_index}",
        "order_index": order_index,
        "mood": mood or "",
        "colors": colors or "",
        "movement_style": movement_style or "",
        "eye_candy": eye_candy or "",
        "special_notes": special_notes or "",
        "general_notes": general_notes or "",
    }

    next_song_id += 1
    show["songs"].append(song)
    return song


def remove_song_from_show(show: Show, song_id: int) -> None:
    """Entfernt einen Song aus der Show und nummeriert neu durch."""
    songs = show.get("songs", [])
    songs = [s for s in songs if s.get("id") != song_id]
    for idx, s in enumerate(songs, start=1):
        s["order_index"] = idx
    show["songs"] = songs


def create_check_item(show: Show, category: str, text: str) -> None:
    """Fügt einen neuen Punkt zur angegebenen Checkliste hinzu."""
    global next_check_item_id

    if "checklists" not in show or not isinstance(show["checklists"], dict):
        show["checklists"] = _empty_checklists()

    if category not in show["checklists"]:
        return

    item = {
        "id": next_check_item_id,
        "text": text,
        "done": False,
    }
    next_check_item_id += 1
    show["checklists"][category].append(item)


def toggle_check_item(show: Show, category: str, item_id: int) -> None:
    """Schaltet den Status eines Checklisten-Eintrags um."""
    if "checklists" not in show or category not in show["checklists"]:
        return

    for item in show["checklists"][category]:
        if item.get("id") == item_id:
            item["done"] = not item.get("done", False)
            break


def remove_show(show_id: int) -> None:
    """Entfernt eine komplette Show aus der Liste."""
    global shows
    shows = [s for s in shows if s.get("id") != show_id]


def duplicate_show(show_id: int) -> Optional[Show]:
    """Erzeugt eine Kopie einer bestehenden Show (inkl. Songs & Checklisten)."""
    global shows, next_show_id, next_song_id, next_check_item_id

    original = find_show(show_id)
    if not original:
        return None

    new_show: Show = copy.deepcopy(original)
    new_show["id"] = next_show_id
    next_show_id += 1

    base_name = new_show.get("name") or f"Show {new_show['id']}"
    new_show["name"] = f"{base_name} (Kopie)"
    new_show["date"] = ""  # Datum bei Kopie leeren

    # Songs: neue IDs + saubere order_index
    new_songs: List[Song] = []
    for idx, song in enumerate(new_show.get("songs", []), start=1):
        song["id"] = next_song_id
        song["order_index"] = idx
        next_song_id += 1
        new_songs.append(song)
    new_show["songs"] = new_songs

    # Checklisten: neue Item-IDs
    cl = new_show.get("checklists")
    if isinstance(cl, dict):
        for key in ("preproduction", "aufbau", "show"):
            items = cl.get(key, [])
            if not isinstance(items, list):
                cl[key] = []
                continue
            new_items = []
            for item in items:
                item["id"] = next_check_item_id
                next_check_item_id += 1
                new_items.append(item)
            cl[key] = new_items

    shows.append(new_show)
    save_data()
    return new_show


# -----------------------------------------------------------------------------
# Logo-Hilfsfunktion
# -----------------------------------------------------------------------------

def _find_logo_path() -> Optional[str]:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    staticimg_dir = os.path.join(base_dir, "static", "staticimg")

    candidates = [
        os.path.join(staticimg_dir, "LightBlastblack .png"),
        os.path.join(staticimg_dir, "LightBlastblack.png"),
        os.path.join(staticimg_dir, "LightBlast_Logo_B_1024.png"),
        os.path.join(staticimg_dir, "staticimglogo.png"),
    ]

    for path in candidates:
        print("[LOGO-CHECK] Prüfe", path, "->", os.path.exists(path))
        if os.path.exists(path):
            return path

    if os.path.isdir(staticimg_dir):
        for fname in os.listdir(staticimg_dir):
            if fname.lower().endswith(".png"):
                fallback = os.path.join(staticimg_dir, fname)
                print("[LOGO-CHECK] Fallback PNG:", fallback)
                return fallback

    print("[LOGO-CHECK] Kein Logo gefunden")
    return None


# Daten beim Start laden
load_data()

# -----------------------------------------------------------------------------
# Routes
# -----------------------------------------------------------------------------

@app.route("/", methods=["GET", "POST"])
def dashboard():
    """Dashboard: Shows anlegen und Übersicht."""
    global shows

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        artist = request.form.get("artist", "").strip()
        date = request.form.get("date", "").strip()
        venue_type = request.form.get("venue_type", "").strip()
        genre = request.form.get("genre", "").strip()
        rig_type = request.form.get("rig_type", "").strip()

        show = create_default_show(
            name=name,
            artist=artist,
            date=date,
            venue_type=venue_type,
            genre=genre,
            rig_type=rig_type,
        )
        shows.append(show)
        save_data()

        return redirect(url_for("show_detail", show_id=show["id"]))

    return render_template("index.html", shows=shows)


@app.route("/show/<int:show_id>/duplicate", methods=["POST"])
def duplicate_show_route(show_id: int):
    """Route: Show duplizieren und direkt zur neuen Show springen."""
    new_show = duplicate_show(show_id)
    if not new_show:
        return redirect(url_for("dashboard"))
    return redirect(url_for("show_detail", show_id=new_show["id"]))


@app.route("/show/<int:show_id>", methods=["GET", "POST"])
def show_detail(show_id: int):
    """Show-Detailseite: Stammdaten, Songs, Rig, Checklisten."""
    show = find_show(show_id)
    if not show:
        abort(404)

    if request.method == "POST":
        action = request.form.get("action")

        if action == "update_meta":
            show["name"] = request.form.get("name", "").strip() or show["name"]
            show["artist"] = request.form.get("artist", "").strip()
            show["date"] = request.form.get("date", "").strip()
            show["venue_type"] = request.form.get("venue_type", "").strip()
            show["genre"] = request.form.get("genre", "").strip()
            show["rig_type"] = request.form.get("rig_type", "").strip()
            show["regie"] = request.form.get("regie", "").strip()
            show["veranstalter"] = request.form.get("veranstalter", "").strip()
            show["vt_firma"] = request.form.get("vt_firma", "").strip()
            show["technischer_leiter"] = request.form.get("technischer_leiter", "").strip()
            show["notes"] = request.form.get("notes", "").strip()
            save_data()

        elif action == "add_song":
            name = request.form.get("song_name", "").strip()
            mood = request.form.get("song_mood", "").strip()
            colors = request.form.get("song_colors", "").strip()
            movement_style = request.form.get("song_movement_style", "").strip()
            eye_candy = request.form.get("song_eye_candy", "").strip()
            special_notes = request.form.get("song_special_notes", "").strip()
            general_notes = request.form.get("song_general_notes", "").strip()

            create_song(
                show=show,
                name=name,
                mood=mood,
                colors=colors,
                movement_style=movement_style,
                eye_candy=eye_candy,
                special_notes=special_notes,
                general_notes=general_notes,
            )
            save_data()

        elif action == "update_rig":
            rig = show["rig_setup"]
            rig["spots"] = request.form.get("rig_spots", "").strip()
            rig["washes"] = request.form.get("rig_washes", "").strip()
            rig["beams"] = request.form.get("rig_beams", "").strip()
            rig["blinders"] = request.form.get("rig_blinders", "").strip()
            rig["strobes"] = request.form.get("rig_strobes", "").strip()
            rig["positions"] = request.form.get("rig_positions", "").strip()
            rig["notes"] = request.form.get("rig_notes", "").strip()
            # neue Strom-Felder
            rig["power_main"] = request.form.get("rig_power_main", "").strip()
            rig["power_light"] = request.form.get("rig_power_light", "").strip()
            rig["power_sound"] = request.form.get("rig_power_sound", "").strip()
            rig["power_video"] = request.form.get("rig_power_video", "").strip()
            rig["power_foh"] = request.form.get("rig_power_foh", "").strip()
            rig["power_other"] = request.form.get("rig_power_other", "").strip()
            save_data()

        elif action == "add_check_item":
            category = request.form.get("category", "")
            text = request.form.get("text", "").strip()
            if category in ("preproduction", "aufbau", "show") and text:
                create_check_item(show, category, text)
                save_data()

        elif action == "toggle_check_item":
            category = request.form.get("category", "")
            item_id_raw = request.form.get("item_id", "")
            try:
                item_id = int(item_id_raw)
            except (TypeError, ValueError):
                item_id = None

            if category in ("preproduction", "aufbau", "show") and item_id is not None:
                toggle_check_item(show, category, item_id)
                save_data()

        elif action == "update_check_item":
            category = request.form.get("category", "")
            item_id_raw = request.form.get("item_id", "")
            text = request.form.get("text", "").strip()

            try:
                item_id = int(item_id_raw)
            except (TypeError, ValueError):
                item_id = None

            if (
                category in ("preproduction", "aufbau", "show")
                and item_id is not None
                and "checklists" in show
                and isinstance(show["checklists"], dict)
            ):
                items = show["checklists"].get(category, [])
                for item in items:
                    if item.get("id") == item_id:
                        item["text"] = text
                        break
                save_data()

        return redirect(url_for("show_detail", show_id=show["id"]))

    return render_template("show_detail.html", show=show)


@app.route("/show/<int:show_id>/delete", methods=["POST"])
def delete_show(show_id: int):
    """Route: komplette Show löschen."""
    if not find_show(show_id):
        abort(404)
    remove_show(show_id)
    save_data()
    return redirect(url_for("dashboard"))


@app.route("/show/<int:show_id>/delete_song", methods=["POST"])
def delete_song(show_id: int):
    """Route: einzelne Szene/Song aus Show löschen."""
    show = find_show(show_id)
    if not show:
        abort(404)

    song_id_raw = request.form.get("song_id", "")
    try:
        song_id = int(song_id_raw)
    except (TypeError, ValueError):
        return redirect(url_for("show_detail", show_id=show_id))

    remove_song_from_show(show, song_id)
    save_data()
    return redirect(url_for("show_detail", show_id=show_id))


@app.route("/show/<int:show_id>/update_song", methods=["POST"])
def update_song(show_id: int):
    """Song / Szene nachträglich bearbeiten."""
    show = find_show(show_id)
    if not show:
        abort(404)

    song_id_raw = request.form.get("song_id", "")
    try:
        song_id = int(song_id_raw)
    except (TypeError, ValueError):
        return redirect(url_for("show_detail", show_id=show_id))

    for song in show.get("songs", []):
        if song.get("id") == song_id:
            name = request.form.get("song_name", "").strip()
            if name:
                song["name"] = name

            song["mood"] = request.form.get("song_mood", "").strip()
            song["colors"] = request.form.get("song_colors", "").strip()
            song["movement_style"] = request.form.get("song_movement_style", "").strip()
            song["eye_candy"] = request.form.get("song_eye_candy", "").strip()
            song["special_notes"] = request.form.get("song_special_notes", "").strip()
            song["general_notes"] = request.form.get("song_general_notes", "").strip()
            break

    save_data()
    return redirect(url_for("show_detail", show_id=show_id))


@app.route("/show/<int:show_id>/move_song", methods=["POST"])
def move_song(show_id: int):
    """Song in der Reihenfolge nach oben/unten verschieben."""
    show = find_show(show_id)
    if not show:
        abort(404)

    song_id_raw = request.form.get("song_id", "")
    direction = request.form.get("direction", "")

    try:
        song_id = int(song_id_raw)
    except (TypeError, ValueError):
        return redirect(url_for("show_detail", show_id=show_id))

    songs = show.get("songs", [])
    index = None
    for i, s in enumerate(songs):
        if s.get("id") == song_id:
            index = i
            break

    if index is None:
        return redirect(url_for("show_detail", show_id=show_id))

    if direction == "up" and index > 0:
        songs[index - 1], songs[index] = songs[index], songs[index - 1]
    elif direction == "down" and index < len(songs) - 1:
        songs[index + 1], songs[index] = songs[index], songs[index + 1]

    for idx, s in enumerate(songs, start=1):
        s["order_index"] = idx

    show["songs"] = songs
    save_data()
    return redirect(url_for("show_detail", show_id=show_id))


# -------------------------------------------------------------------------
# Show-Report-PDF (internes LD-Dokument – Songs + Rig + Checklisten)
# -------------------------------------------------------------------------
@app.route("/show/<int:show_id>/export_pdf")
def export_show_pdf(show_id: int):
    """Erzeugt eine PDF-Datei mit Showdaten, Logo, Songs/Szenen, Rig und Checklisten."""
    show = find_show(show_id)
    if not show:
        return redirect(url_for("dashboard"))

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Logo
    logo_path = _find_logo_path()
    if logo_path:
        try:
            logo = ImageReader(logo_path)
            orig_w, orig_h = logo.getSize()

            desired_width = 110.0
            scale = desired_width / float(orig_w)
            desired_height = orig_h * scale

            top_margin = 40.0
            x = 40.0
            y_logo = height - top_margin - desired_height

            pdf.drawImage(
                logo,
                x,
                y_logo,
                width=desired_width,
                height=desired_height,
                mask="auto",
                preserveAspectRatio=True,
            )
        except Exception as e:
            print("[LOGO-CHECK] Fehler beim Laden des Logos:", e)

    # Kopf
    pdf.setFont("Helvetica-Bold", 18)
    pdf.drawString(180, height - 60, "Lichtdesign-Assistent – Show Report")

    pdf.setFont("Helvetica", 12)
    y = height - 140
    line_height = 18

    def write(label: str, value: str) -> None:
        nonlocal y
        pdf.drawString(40, y, f"{label}: {value if value else '–'}")
        y -= line_height

    write("Showname", show.get("name", ""))
    write("Artist / Produktion", show.get("artist", ""))
    write("Datum", show.get("date", ""))
    write("Venue-Typ", show.get("venue_type", ""))
    write("Genre", show.get("genre", ""))
    write("Rig-Typ", show.get("rig_type", ""))

    pdf.line(40, y, width - 40, y)
    y -= line_height

    # -------------------------------------------------------------------------
    # Songs / Szenen (DETAIL)
    # -------------------------------------------------------------------------
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(40, y, "Songs / Szenen")
    y -= line_height

    pdf.setFont("Helvetica", 11)

    if show.get("songs"):
        for song in show["songs"]:
            if y < 100:
                pdf.showPage()
                y = height - 60
                pdf.setFont("Helvetica-Bold", 14)
                pdf.drawString(40, y, "Songs / Szenen (Fortsetzung)")
                y -= line_height
                pdf.setFont("Helvetica", 11)

            title = f"{song.get('order_index', ''):>2} – {song.get('name', '')}"
            pdf.setFont("Helvetica-Bold", 11)
            pdf.drawString(50, y, title)
            y -= line_height

            pdf.setFont("Helvetica", 10)

            def write_song_line(label: str, key: str) -> None:
                nonlocal y
                text = song.get(key, "")
                if text:
                    pdf.drawString(60, y, f"{label}: {text}")
                    y -= line_height

            write_song_line("Stimmung", "mood")
            write_song_line("Farben", "colors")
            write_song_line("Bewegung", "movement_style")
            write_song_line("Eye-Candy", "eye_candy")
            write_song_line("Specials", "special_notes")
            write_song_line("Notizen", "general_notes")

            y -= line_height / 2
    else:
        pdf.drawString(50, y, "Keine Songs/Szenen erfasst.")
        y -= line_height

    # -------------------------------------------------------------------------
    # Rig / Setup inkl. Strom
    # -------------------------------------------------------------------------
    rig = show.get("rig_setup", {})
    if isinstance(rig, dict):
        rig_has_content = any(
            (rig.get(k) or "").strip()
            for k in [
                "spots",
                "washes",
                "beams",
                "blinders",
                "strobes",
                "positions",
                "notes",
                "power_main",
                "power_light",
                "power_sound",
                "power_video",
                "power_foh",
                "power_other",
            ]
        )
        if rig_has_content:
            if y < 120:
                pdf.showPage()
                y = height - 60

            pdf.setFont("Helvetica-Bold", 14)
            pdf.drawString(40, y, "Rig / Setup")
            y -= line_height
            pdf.setFont("Helvetica", 10)

            def write_rig_line(label: str, key: str) -> None:
                nonlocal y
                val = (rig.get(key) or "").strip()
                if not val:
                    return
                pdf.drawString(50, y, f"{label}: {val}")
                y -= line_height

            # Fixture-Übersicht
            write_rig_line("Spots (Anzahl)", "spots")
            write_rig_line("Washes (Anzahl)", "washes")
            write_rig_line("Beams (Anzahl)", "beams")
            write_rig_line("Blinder (Anzahl)", "blinders")
            write_rig_line("Strobes (Anzahl)", "strobes")

            positions = (rig.get("positions") or "").strip()
            if positions:
                pdf.drawString(50, y, f"Positionen: {positions}")
                y -= line_height

            notes_rig = (rig.get("notes") or "").strip()
            if notes_rig:
                pdf.drawString(50, y, f"Besondere Hinweise / Truss / Höhe: {notes_rig}")
                y -= line_height

            # Strom / Infrastruktur
            power_main = (rig.get("power_main") or "").strip()
            power_light = (rig.get("power_light") or "").strip()
            power_sound = (rig.get("power_sound") or "").strip()
            power_video = (rig.get("power_video") or "").strip()
            power_foh = (rig.get("power_foh") or "").strip()
            power_other = (rig.get("power_other") or "").strip()

            if any([power_main, power_light, power_sound, power_video, power_foh, power_other]):
                y -= line_height * 0.5
                if y < 80:
                    pdf.showPage()
                    y = height - 60
                    pdf.setFont("Helvetica-Bold", 14)
                    pdf.drawString(40, y, "Rig / Setup (Fortsetzung)")
                    y -= line_height
                    pdf.setFont("Helvetica", 10)

                pdf.setFont("Helvetica-Bold", 11)
                pdf.drawString(50, y, "Strom / Infrastruktur")
                y -= line_height
                pdf.setFont("Helvetica", 10)

                if power_main:
                    pdf.drawString(60, y, f"Hauptversorgung: {power_main}")
                    y -= line_height
                if power_light:
                    pdf.drawString(60, y, f"Licht / Dimmer: {power_light}")
                    y -= line_height
                if power_sound:
                    pdf.drawString(60, y, f"Audio: {power_sound}")
                    y -= line_height
                if power_video:
                    pdf.drawString(60, y, f"Video / LED: {power_video}")
                    y -= line_height
                if power_foh:
                    pdf.drawString(60, y, f"FOH / Pultplatz: {power_foh}")
                    y -= line_height
                if power_other:
                    pdf.drawString(60, y, f"Sonstiges: {power_other}")
                    y -= line_height

            y -= line_height / 2

    # -------------------------------------------------------------------------
    # Checklisten (DETAIL)
    # -------------------------------------------------------------------------
    checklists = show.get("checklists", {})
    if isinstance(checklists, dict):
        if y < 120:
            pdf.showPage()
            y = height - 60

        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(40, y, "Checklisten")
        y -= line_height

        def ensure_space_for_block(min_height: float, heading: str) -> None:
            nonlocal y
            if y < min_height:
                pdf.showPage()
                y = height - 60
                pdf.setFont("Helvetica-Bold", 14)
                pdf.drawString(40, y, f"{heading} (Fortsetzung)")
                y -= line_height
                pdf.setFont("Helvetica", 10)

        sections = [
            ("preproduction", "Preproduction"),
            ("aufbau", "Aufbau"),
            ("show", "Showtag"),
        ]

        pdf.setFont("Helvetica", 10)

        for key, label in sections:
            items = checklists.get(key, [])
            if not isinstance(items, list) or not items:
                continue

            ensure_space_for_block(80, "Checklisten")

            pdf.setFont("Helvetica-Bold", 11)
            pdf.drawString(50, y, label)
            y -= line_height

            pdf.setFont("Helvetica", 10)
            for item in items:
                if y < 60:
                    pdf.showPage()
                    y = height - 60
                    pdf.setFont("Helvetica-Bold", 14)
                    pdf.drawString(40, y, "Checklisten (Fortsetzung)")
                    y -= line_height
                    pdf.setFont("Helvetica-Bold", 11)
                    pdf.drawString(50, y, label)
                    y -= line_height
                    pdf.setFont("Helvetica", 10)

                text = item.get("text", "")
                done = bool(item.get("done", False))
                prefix = "[x]" if done else "[ ]"
                pdf.drawString(60, y, f"{prefix} {text}")
                y -= line_height * 0.9

            y -= line_height * 0.5

    pdf.setFont("Helvetica-Oblique", 9)
    pdf.drawString(40, 40, "Automatisch generiert mit dem Lichtdesign-Assistent v2")

    pdf.save()
    buffer.seek(0)

    filename = (show.get("name") or "show").replace(" ", "_") + ".pdf"

    return send_file(
        buffer,
        as_attachment=True,
        download_name=filename,
        mimetype="application/pdf",
    )


# -------------------------------------------------------------------------
# Tech-Rider-PDF (extern: Stammdaten, Kontakte, Setlist, Rig + Strom)
# -------------------------------------------------------------------------
@app.route("/show/<int:show_id>/export_techrider")
def export_techrider_pdf(show_id: int):
    """Erzeugt eine kompakte Tech-Rider-PDF mit Stammdaten, Kontakten, Setlist und Rig/Strom."""
    show = find_show(show_id)
    if not show:
        return redirect(url_for("dashboard"))

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Logo
    logo_path = _find_logo_path()
    if logo_path:
        try:
            logo = ImageReader(logo_path)
            orig_w, orig_h = logo.getSize()

            desired_width = 110.0
            scale = desired_width / float(orig_w)
            desired_height = orig_h * scale

            top_margin = 40.0
            x = 40.0
            y_logo = height - top_margin - desired_height

            pdf.drawImage(
                logo,
                x,
                y_logo,
                width=desired_width,
                height=desired_height,
                mask="auto",
                preserveAspectRatio=True,
            )
        except Exception as e:
            print("[LOGO-CHECK] Fehler beim Laden des Logos:", e)

    # Kopf
    pdf.setFont("Helvetica-Bold", 18)
    pdf.drawString(180, height - 60, "Lichtdesign-Assistent – Tech Rider")

    pdf.setFont("Helvetica", 12)
    y = height - 140
    line_height = 18

    def write(label: str, value: str) -> None:
        nonlocal y
        pdf.drawString(40, y, f"{label}: {value if value else '–'}")
        y -= line_height

    # Stammdaten
    write("Showname", show.get("name", ""))
    write("Artist / Produktion", show.get("artist", ""))
    write("Datum", show.get("date", ""))
    write("Venue-Typ", show.get("venue_type", ""))
    write("Genre", show.get("genre", ""))
    write("Rig-Typ", show.get("rig_type", ""))

    pdf.line(40, y, width - 40, y)
    y -= line_height

    # Kontaktdaten / Verantwortliche
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(40, y, "Kontaktdaten / Verantwortliche")
    y -= line_height

    pdf.setFont("Helvetica", 11)
    write("Regie", show.get("regie", ""))
    write("Veranstalter", show.get("veranstalter", ""))
    write("VT-Firma", show.get("vt_firma", ""))
    write("Technischer Leiter", show.get("technischer_leiter", ""))

    # Allgemeine Notizen / Hinweise
    notes = (show.get("notes") or "").strip()
    if notes:
        pdf.setFont("Helvetica-Bold", 12)
        pdf.drawString(40, y, "Allgemeine Hinweise / Notizen")
        y -= line_height
        pdf.setFont("Helvetica", 10)

        max_chars = 90
        while notes:
            line = notes[:max_chars]
            notes = notes[max_chars:]
            if y < 60:
                pdf.showPage()
                y = height - 60
                pdf.setFont("Helvetica", 10)
            pdf.drawString(50, y, line)
            y -= line_height * 0.9

        y -= line_height * 0.5

    # ---------------------------------------------------------------------
    # Setlist (Übersicht, extern lesbar, keine Detail-LD-Notizen)
    # ---------------------------------------------------------------------
    songs = show.get("songs", [])
    if isinstance(songs, list) and songs:
        if y < 140:
            pdf.showPage()
            y = height - 60

        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(40, y, "Setlist (Übersicht)")
        y -= line_height

        pdf.setFont("Helvetica", 10)
        for song in sorted(songs, key=lambda s: s.get("order_index", 0)):
            if y < 60:
                pdf.showPage()
                y = height - 60
                pdf.setFont("Helvetica-Bold", 14)
                pdf.drawString(40, y, "Setlist (Fortsetzung)")
                y -= line_height
                pdf.setFont("Helvetica", 10)

            name = song.get("name", "")
            idx = song.get("order_index", "")
            mood = (song.get("mood") or "").strip()
            line = f"{idx:02d} – {name}"
            if mood:
                line += f"  (Stimmung: {mood})"

            pdf.drawString(50, y, line)
            y -= line_height * 0.9

        y -= line_height * 0.5

    # ---------------------------------------------------------------------
    # Rig / Setup inkl. Strom – Fokus auf Anforderungen
    # ---------------------------------------------------------------------
    rig = show.get("rig_setup", {})
    if isinstance(rig, dict):
        rig_has_content = any(
            (rig.get(k) or "").strip()
            for k in [
                "spots",
                "washes",
                "beams",
                "blinders",
                "strobes",
                "positions",
                "notes",
                "power_main",
                "power_light",
                "power_sound",
                "power_video",
                "power_foh",
                "power_other",
            ]
        )
        if rig_has_content:
            if y < 140:
                pdf.showPage()
                y = height - 60

            pdf.setFont("Helvetica-Bold", 14)
            pdf.drawString(40, y, "Rig / Setup – Anforderungen")
            y -= line_height
            pdf.setFont("Helvetica", 10)

            def write_rig_line(label: str, key: str) -> None:
                nonlocal y
                val = (rig.get(key) or "").strip()
                if not val:
                    return
                if y < 60:
                    pdf.showPage()
                    y = height - 60
                    pdf.setFont("Helvetica", 10)
                pdf.drawString(50, y, f"{label}: {val}")
                y -= line_height

            # Fixtures grob
            write_rig_line("Spots (Anzahl)", "spots")
            write_rig_line("Washes (Anzahl)", "washes")
            write_rig_line("Beams (Anzahl)", "beams")
            write_rig_line("Blinder (Anzahl)", "blinders")
            write_rig_line("Strobes (Anzahl)", "strobes")

            positions = (rig.get("positions") or "").strip()
            if positions:
                if y < 60:
                    pdf.showPage()
                    y = height - 60
                    pdf.setFont("Helvetica", 10)
                pdf.drawString(50, y, f"Positionen (Front/Side/Back/Floor): {positions}")
                y -= line_height

            notes_rig = (rig.get("notes") or "").strip()
            if notes_rig:
                if y < 60:
                    pdf.showPage()
                    y = height - 60
                    pdf.setFont("Helvetica", 10)
                pdf.drawString(50, y, f"Besondere Hinweise / Truss / Höhe: {notes_rig}")
                y -= line_height

            # Strom / Infrastruktur – zentraler Teil des Tech-Riders
            power_main = (rig.get("power_main") or "").strip()
            power_light = (rig.get("power_light") or "").strip()
            power_sound = (rig.get("power_sound") or "").strip()
            power_video = (rig.get("power_video") or "").strip()
            power_foh = (rig.get("power_foh") or "").strip()
            power_other = (rig.get("power_other") or "").strip()

            if any([power_main, power_light, power_sound, power_video, power_foh, power_other]):
                y -= line_height * 0.5
                if y < 80:
                    pdf.showPage()
                    y = height - 60
                    pdf.setFont("Helvetica", 10)

                pdf.setFont("Helvetica-Bold", 11)
                pdf.drawString(50, y, "Strom / Infrastruktur (Anforderungen)")
                y -= line_height
                pdf.setFont("Helvetica", 10)

                if power_main:
                    pdf.drawString(60, y, f"Hauptversorgung: {power_main}")
                    y -= line_height
                if power_light:
                    pdf.drawString(60, y, f"Licht / Dimmer: {power_light}")
                    y -= line_height
                if power_sound:
                    pdf.drawString(60, y, f"Audio: {power_sound}")
                    y -= line_height
                if power_video:
                    pdf.drawString(60, y, f"Video / LED: {power_video}")
                    y -= line_height
                if power_foh:
                    pdf.drawString(60, y, f"FOH / Pultplatz: {power_foh}")
                    y -= line_height
                if power_other:
                    pdf.drawString(60, y, f"Sonstiges: {power_other}")
                    y -= line_height

            y -= line_height * 0.5

    pdf.setFont("Helvetica-Oblique", 9)
    pdf.drawString(
        40,
        40,
        "Detail-Checklisten und Szenen-Infos siehe Show-Report (internes Dokument)."
    )

    pdf.save()
    buffer.seek(0)

    filename_base = (show.get("name") or "show").replace(" ", "_")
    filename = filename_base + "_TechRider.pdf"

    return send_file(
        buffer,
        as_attachment=True,
        download_name=filename,
        mimetype="application/pdf",
    )


if __name__ == "__main__":
    app.run(debug=True)
